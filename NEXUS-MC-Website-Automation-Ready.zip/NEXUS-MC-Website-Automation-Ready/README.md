# NEXUS MC — website automation integration

This repository is a **standalone integration preview**, not the full source code of the existing ChatGPT Sites website. Do not replace its homepage with this `index.html`.

## GitHub setup
1. Create a new GitHub repository named `nexus-mc-website` using your account (GitHub → New repository). Choose private if you want to work privately, but the releases API used by the browser widget requires a **public** repository to fetch without credentials. Prefer publishing a separate public releases repository if the website source should remain private.
2. Upload these files (including `.github/workflows/validate.yml`).
3. In `config.json`, set `githubRepo` to your actual **public** owner/repository name.
4. Publish GitHub Releases using versions for **NEXUS MC itself**. Releases for the separate raid plugin have their own version cycle and should be clearly labelled or tracked in a separate feed.
5. Publish an official release with a tag e.g. `mc-2026.11.01`. This will automatically appear in the widget after its next refresh once that widget has been integrated into the live site's source.

## Raid status
`raidStatusUrl` requires an HTTPS JSON status endpoint containing `state`, `bossName`, `players`, `nextRaidAt`, and `updatedAt`. Until the server publishes one, the widget correctly says not connected. Do not expose RCON or player-identifying data. Allow CORS from `https://nexusmc.nexusukrp.co.uk`.

## Live deployment
The live domain is currently a DNS-only CNAME pointing to `custom-domains.chatgpt.site`. Its original source and editor aren't available through this GitHub repository. Merge the updates and raid panel into the original website project before publishing from ChatGPT Sites. Don't change Cloudflare DNS or upload this preview over your existing website.

## Development
Run `python -m http.server 8080` in this folder to preview. GitHub Actions checks source syntax, but does not publish the existing site.
